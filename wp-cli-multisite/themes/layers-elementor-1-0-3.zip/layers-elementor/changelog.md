# Layers Changelog

##1.0.0
### 13 November 2018

##1.0.1
### 13 November 2018

* **Fix** - Updated CSS to accomodate Elementor elements in a better way

##1.0.2
### 26 May 2019

* **Fix** - Elementor maintenance mode now works
* **Fix** - 404 and other custom archive templates work correctly
* **Fix** - Pages no longer default to the "Blank Page" template when saving Elementor pages


##1.0.3
### 28 Jan 2020

* **Fix** - Fixed custom search templates
* **Fix** - Fixed continue warning in post pages
* **Fix** - Fixed side header layout (will only trigger on pages without custom headers and footers)