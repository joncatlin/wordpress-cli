<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*
 * View of RealTime Dashboard
 */
function show_realtime_dashboard ( $current ) {

  ?>


  <?php

} ?>
